﻿using System;
using System.IO;
using System.Threading;
namespace Assignment1
{
    class Login
    {
        //Declare data members.
        string userName, passWord;

        //Method to display Login Screen and allow user input.
        public void LoginScreen()
        {

        Console.Clear();
        passWord = "";
        Console.WriteLine("|----------------------------------------|");
        Console.WriteLine("         WELCOME TO ONLINE BANKING        ");
        Console.WriteLine("|----------------------------------------|");
        Console.WriteLine("             LOGIN TO START               ");
        Console.WriteLine("                                          ");
        Console.WriteLine("                                          ");
        Console.Write("             User Name:");
        userName = Console.ReadLine();
        // to capture postiion of cursor 
        int CursorPosUserNameLeft = Console.CursorLeft;
        int CursorPosUserNameTop = Console.CursorTop;
        Console.SetCursorPosition(CursorPosUserNameLeft, CursorPosUserNameTop);
        Console.Write("             Password:");
        // to capture postiion of cursor
        int CursorPosPassWordLeft = Console.CursorLeft;
        int CursorPosPassWordTop = Console.CursorTop;
        Console.SetCursorPosition(CursorPosPassWordLeft, CursorPosPassWordTop);
        // Infinite loop to concatenate and display stars instead of words using ReadKey.
        string passChar = "*";

            do
        {
            ConsoleKeyInfo Key = Console.ReadKey(true);
	        // if not backspace and enter then record as password 
	        if
		        (Key.Key != ConsoleKey.Backspace && Key.Key != ConsoleKey.Enter)
	        {
		        passWord += Key.KeyChar;
		        Console.Write(passChar);
	        }
	        // if backspace or enter do delete. Substring is used to remove it.
	        else if (Key.Key == ConsoleKey.Backspace && passWord.Length > 0)
	        {
		        passWord = passWord.Substring(0, (passWord.Length - 1));
		        Console.Write("\b \b");
	        }
	        // Break if when we enter backspace.
	        if (Key.Key == ConsoleKey.Enter)
	        {
		        break;
	        }
        } while (true);
	        Console.WriteLine();
	        Console.WriteLine("|----------------------------------------|");
	        // Method to check credetianls is called here! 
	        var isValid = ValidateCredential();
            if (isValid)
	        {
		        Console.WriteLine("Valid Credentials...!");
		        // Take to the MainMenuScreen();
		        MainMenu mainMenu = new MainMenu();
		        int option = mainMenu.ShowOptions();
		        while (option != 7)
		        {
			        Console.WriteLine("Please enter a key to go back....");
			        Console.ReadKey();
			        option = mainMenu.ShowOptions();
		        }
	        }
            else
	        {
                Console.WriteLine("Invaild Credentials - Try again");
		        Thread.Sleep(3000);
		        LoginScreen();
	        }
            }

        //Method that returts true or false to check credentials against login.txt file.
        //Split each line using "|" as delimiter and print values entered.
        private bool ValidateCredential()
        {                     
        FileStream F = new FileStream("login.txt", FileMode.Open, FileAccess.Read,
        FileShare.Read);
        Console.WriteLine("You have entered the following:\n Username: " + userName + "\n Password: " + passWord);
        int i;
        string[] LoginCredentials = File.ReadAllLines("login.txt");
            for (i = 0; i < LoginCredentials.Length; i++)
            {
	            //Split Line (Credential[0] = Username, Credential[1] = Password)
	            string[] Credential = LoginCredentials[i].Split('|');

	            //Check if input matches
	            if (userName == Credential[0] && passWord == Credential[1])
	            {
		            return true;
	            }
                }
                return false;
            }
    }
 }