﻿using System;
namespace Assignment1
{
    public class Employee
    {
        public Employee()
        {
        }
    }
}
