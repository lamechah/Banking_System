﻿using System;
using System.Collections;
using System.IO;
using System.Threading;

namespace Assignment1
{
    //Create the Customer class by inheriting the Account Class and implementing the IBankStatements interface
    public class Customer: Account, IBankStatements
    {
        string folderPath = "Accounts/accountIndex.txt";
        // Write code for Data members specific to a Customer
        private string firstName;
        private string lastName;
        private string phone;
        private string address;
        private string email;
        private double balance;
        private ArrayList transactions;

        //Enable class variables to expose in public way using get and set accessors.
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        public double Balance
        {
            get { return balance; }
            set { balance = value; }
        }
        public ArrayList Transactions
        {
            get { return transactions; }
            set { transactions = value; }
        }

        // Write code for Customer Constructor, which also initializes the base class properties.
        public Customer(int accountId, string firstName, string lastName, string phone, string address, string email, double balance, ArrayList transactions) : base(accountId)
        {
            //use keywrod this to qualify the fields.
            this.firstName = firstName;
            this.lastName = lastName;
            this.phone = phone;
            this.address = address;
            this.email = email;
            this.balance = balance;
            this.transactions = transactions;
        }

        // Implement method to deposti to account.
        public double Deposit()
        {
            double amount;
            do
            {
                Console.WriteLine("|----------------------------------------|");
                Console.Write("Deposit amount: ");
                var userInput = Console.ReadLine();
                // to capture postiion of cursos 
                int CursorPodLeft = Console.CursorLeft;
                int CursorPosTop = Console.CursorTop;
                Console.SetCursorPosition(CursorPodLeft, CursorPosTop);

               amount = Convert.ToDouble(userInput);

                if (amount <= 0)
                {
                    Console.WriteLine("|----------------------------------------|");
                    Console.WriteLine("You must deposit more that 0");
                }  
            }
            while (amount <= 0);
            balance += amount;
            string transaction = "Transaction details: Deposit with amount " + amount;
            transactions.Add(transaction);
            SaveToFile();
            return balance;
        }

        // Implement method to display the last 5 transactions inputed by the customer. 
        public void DisplayResult()
        {
            var savedTransaction = GetLastTransactions();
            Console.WriteLine("|----------------------------------------------|");
            Console.WriteLine("From oldest to newest last 5 transactions are:");
            foreach (string i in savedTransaction)
            {
                Console.WriteLine("- "+i);
            }
        }

        // Implement method to withdraw from account if possible. 
        public double Withdraw()
        {
            double amount; 
            do
            {
                Console.WriteLine("|----------------------------------------|");
                Console.Write("Withraw amount: ");
                var userInput = Console.ReadLine();
                // to capture postiion of cursos 
                int CursorPodLeft = Console.CursorLeft;
                int CursorPosTop = Console.CursorTop;
                Console.SetCursorPosition(CursorPodLeft, CursorPosTop);
                amount = Convert.ToDouble(userInput);

                if (amount <= 0)
                {
                    Console.WriteLine("|----------------------------------------|");
                    Console.WriteLine("Please enter an amount greater than 0");
                }

                else if (balance - amount < 0)
                {
                    Console.WriteLine("|----------------------------------------|");
                    Console.WriteLine("Please enter a smaller amount ");
                    Console.WriteLine("You do not have enough balance.");
                    Console.WriteLine("Current balance is {0}", balance);
                }
            }
            while ((amount <= 0) || (balance - amount < 0));
            { }

                balance -= amount;
                string transaction = "Transaction details: Withdraw with amount " + amount;
                transactions.Add(transaction);
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("Transaction details: Withdraw with amount " + amount);
                SaveToFile();
                return balance;
        }

        //Method to save back to the file the account details with current balance and transactions updated. 
        public void SaveToFile()
        {
            //Append text back to index
            string[] content = new string[1];
            content[0] = AccountId.ToString();
            File.WriteAllLines(folderPath, content);

            var path = "Accounts/" + AccountId + ".txt";

            Console.WriteLine("|----------------------------------------|");
            //Console.WriteLine("Your account number is {0}!.", AccountId);

            var savedTransaction = GetLastTransactions();

            using (StreamWriter sw = File.CreateText(path))
            {
                sw.WriteLine("Account Number:" + AccountId);
                sw.WriteLine("Account Balance:" + balance);
                sw.WriteLine("First Name:" + firstName);
                sw.WriteLine("Last Name:" + lastName);
                sw.WriteLine("Address:" + address);
                sw.WriteLine("Phone:" + phone);
                sw.WriteLine("Email:" + email);
                // This is a loop throught savedTransaction array. With each transaction, do sw.writeline to the file
                foreach (string i in savedTransaction)
                {
                    sw.WriteLine(i);
                }
                sw.Close();
            }
        }

        //Create an arraylist to store the last 5 transactions performed by customer. 
        private ArrayList GetLastTransactions()
        {
            if (transactions.Count <= 5)
            {
                return transactions;
            }
            else
            {
                return transactions.GetRange(transactions.Count - 5, 5);
            }
        }

        //Method to delete an account.
        public void DeleteAccount()
        {
            try
            { 
            Console.WriteLine("|----------------------------------------|");
            File.Delete("Accounts/" + AccountId + ".txt");
            Console.WriteLine("Your account {0} was deleted!", AccountId);
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}