﻿using System;
using System.Net.Mail;
using System.IO;
using System.Threading;
using System.Collections;

namespace Assignment1
{
    public class NewCustomer
    {
        //Declare data variables 
        string folderPath = "Accounts/accountIndex.txt";
        private int newAccountNumber;
        string firstName, lastName, phone, address, email;
        const int MaxLength = 10;
        int accountBalance = 0;
        string input;
        public NewCustomer()
        {
        }
        /*/
        Write METHODS that can:
        a)create account
        b)store details
        c)send email
        d)display result
        e)validate information
        f)handle exceptions
        */

        //Method takes input from the customer to create a new account.
        public void CreateAccount()
        {
            Console.Clear();
            Console.WriteLine("|----------------------------------------|");
            Console.WriteLine("         WELCOME TO MAIN MENU        ");
            Console.WriteLine("|----------------------------------------|");
            int CursorPodLeft = Console.CursorLeft;
            int CursorPosTop = Console.CursorTop;
            //For loop to display the fields and position the cursor correctly.
            for (int i = 1; i <= 6; i++)
            {
                switch (i)
                {
                    case 1:
                        Console.Write(" 1.First Name: ");
                        firstName = Console.ReadLine();
                        break;
                    case 2:
                        Console.Write(" 2.Last Name: ");
                        lastName = Console.ReadLine();
                        break;
                    case 3:
                        Console.Write(" 3.Address: ");
                        address = Console.ReadLine();
                        break;
                    case 4:
                        var validPhoneNumber = false;
                        do
                        {
                            Console.Write(" 4.Phone: ");
                            phone = Console.ReadLine();
                            validPhoneNumber = ValidatePhoneNumber(phone);
                        }
                        while (!validPhoneNumber);
                        break;
                    case 5:
                        do
                        {
                            Console.Write(" 5.Email: ");
                            email = Console.ReadLine();
                            if (!email.Contains("@"))
                            {
                                Console.WriteLine("Email must contain @. Please try again ");
                                Thread.Sleep(2000);
                            }
                        }
                        while (!email.Contains("@"));
                        break;
                    case 6:
                        var details = false;
                        do
                        {
                            DisplayDetails();
                            Console.Write(" Are your details correct? (y/n):");
                            input = Console.ReadLine();
                            details = CorrectInfo(input);
                        }
                        while (!details);
                        break;
                    default:
                        break;
                }
                CursorPodLeft = Console.CursorLeft;
                CursorPosTop = Console.CursorTop;
                Console.SetCursorPosition(CursorPodLeft, CursorPosTop);
            }
        }

        //Method confirms with customer if details entered are correct.
        //The account is only created when customer confirms. 
        private bool CorrectInfo(string input2)
        {
            switch (input2)
            {
                case "y":
                    StoreDetails();
                    SendEmail();
                    return true;
                case "n":
                    Console.WriteLine("Your account was not created! We will take you back to Main Menu.");
                    Thread.Sleep(1500);
                    MainMenu menu = new MainMenu();
                    menu.ShowOptions();
                    return true;
                default:
                    Console.WriteLine("That is not a valid option. Please try again!");
                    Thread.Sleep(1500);
                    return false;
            }
        }

        //Method checks if phone format is valid.
        private bool ValidatePhoneNumber(string phone2)
        {
            if ((!int.TryParse(phone2, out int phoneid) || (phone2.Length > MaxLength)))
            {
                Console.WriteLine("Phone field can only contain integers and up to 10 characters.");
                Console.WriteLine("Please input again");
                Thread.Sleep(2000);
                return false;
            }
            else
            {
                return true;
            }
        }

        //Method creates a new customer to store information of the account in a file.
        public void StoreDetails()
        {
            try
            {
                //Generate a new unique account number.
                //Create a new instance of Customer. 
                //Save account details to file.
                string[] index = File.ReadAllLines(folderPath);
                var previousAccount = Convert.ToInt32(index[0]);
                newAccountNumber = previousAccount + 1;
                Customer newCustomer = new Customer(newAccountNumber, firstName, lastName, phone, address, email, accountBalance, new ArrayList());
                newCustomer.SaveToFile();
            }
            catch (Exception)
            {
                Console.Clear();
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("         OOPS! WE ARE SORRY        ");
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("We were not able to create your account.");
                Console.WriteLine("Please contact support and try again!");
                Thread.Sleep(5000);
                MainMenu menu = new MainMenu();
                menu.ShowOptions();
            }
        }

        //Method sends email with account details.
        public void SendEmail()
        {
            try
            {
                var path = "Accounts/" + newAccountNumber + ".txt";
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
                mail.From = new MailAddress("hdbankingapp@gmail.com");
                mail.To.Add(email);
                mail.Subject = "Banking App - Account Details";
                mail.Body = "Hi and welcome to Banking App, please find your new account details attached";

                using (Attachment attachment = new Attachment(path))
                {
                    mail.Attachments.Add(attachment);
                    SmtpServer.Port = 587;
                    SmtpServer.Credentials = new System.Net.NetworkCredential("hdbankingapp@gmail.com", "13416793");
                    SmtpServer.EnableSsl = true;
                    SmtpServer.Send(mail);
                }

                //System.Net.Mail.Attachment attachment;
                //attachment = new System.Net.Mail.Attachment(path);
                //mail.Attachments.Add(attachment);
                //SmtpServer.Port = 587;
                //SmtpServer.Credentials = new System.Net.NetworkCredential("hdbankingapp@gmail.com", "13416793");
                //SmtpServer.EnableSsl = true;
                //SmtpServer.Send(mail);

                Console.WriteLine("Your details were sent! You can now proceed back to the menu");
                Thread.Sleep(2000);
                MainMenu menu = new MainMenu();
                menu.ShowOptions();
            }
            catch (Exception)
            {
                Console.Clear();
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("         OOPS! WE ARE SORRY        ");
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("The email provided was invalid.\nWe could not send the details.");
                Console.WriteLine("You can still operate with your Account Number.");
                Console.WriteLine("Your Account Number is: {0}.", newAccountNumber);
                Console.WriteLine("You can now proceed back to the menu.");
                Thread.Sleep(5000);
                MainMenu menu = new MainMenu();
                menu.ShowOptions();
            }
        }

        //Method displays the information entered by the customer
        private void DisplayDetails()
        {
            Console.Clear();
            Console.WriteLine("|----------------------------------------|");
            Console.WriteLine("            ACCOUNT DETAILS               ");
            Console.WriteLine("|----------------------------------------|");
            Console.WriteLine(" The details of your account entered are:");
            Console.WriteLine();
            Console.WriteLine("|----------------------------------------|");
            Console.WriteLine(" 1.First Name: " + firstName);
            Console.WriteLine(" 2.Last Name:  " + lastName);
            Console.WriteLine(" 3.Address: " + address);
            Console.WriteLine(" 4.Phone: " + phone);
            Console.WriteLine(" 5.Email: " + email);
            Console.WriteLine("|----------------------------------------|");
        }
    }
}


















