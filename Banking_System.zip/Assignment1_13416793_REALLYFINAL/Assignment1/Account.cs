﻿using System;
using System.Collections;

namespace Assignment1
{
    // Create an Abstract class Account
    public abstract class Account
    {
        //Declare data members and properties 
        int accountId;

        // Write code for Constructor
        public Account(int accountId)
        {
            this.accountId = accountId;
        }

        public int AccountId
        {
            set { accountId = value; }
            get { return accountId; }
        }
    }

    // Create an interface of Bank Statements.
    public interface IBankStatements
    {
        // Declare the methods to be inplemented in the class
        double Deposit();
        double Withdraw();
        void DisplayResult();
    }
}
