﻿using System;
using System.IO;
using System.Threading;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create a new object and call method to start the program.
            //Handle exceptions for the whole program with try-catch blocks.
            try
            {
                Login MyBank = new Login();
                MyBank.LoginScreen();
            }
            catch (FileNotFoundException)
            {
                Console.Clear();
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("         OOPS! WE ARE SORRY        ");
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("System couldn't find the details." +
                    "\nPlease contact support and try agian.");
                Thread.Sleep(2500);
                Login MyBank = new Login();
                MyBank.LoginScreen();
            }
            catch (ArgumentNullException ex)
            {
                Console.Clear();
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("         OOPS! WE ARE SORRY        ");
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine(ex.Message);
                Console.WriteLine("Please contact support and try again.");
                Thread.Sleep(2500);
                Login MyBank = new Login();
                MyBank.LoginScreen();
            }
            catch (IndexOutOfRangeException ix)
            {
                Console.Clear();
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("         OOPS! WE ARE SORRY        ");
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine(ix.Message);
                Console.WriteLine("Please contact support and try again.");
                Thread.Sleep(2500);
                Login MyBank = new Login();
                MyBank.LoginScreen();
            }
            catch (Exception e)
            {
                Console.Clear();
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("         OOPS! WE ARE SORRY        ");
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine(e.Message);
                Console.WriteLine ("Please contact support and try again.");
                Thread.Sleep(2500);
                Login MyBank = new Login();
                MyBank.LoginScreen();
            }
 
        }
    }
}