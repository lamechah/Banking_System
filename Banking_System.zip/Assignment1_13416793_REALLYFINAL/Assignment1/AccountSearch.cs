﻿
using System;
using System.Collections;
using System.IO;
using System.Net.Mail;
using System.Threading;

namespace Assignment1
{
    public class AccountSearch
    {
        //Declare data variables.
        string userInput;
        int accountId;
        const int MaxLength = 11;

        public AccountSearch()
        {
        }
        //Method for searching an account.
        public void SearchAccount()
        {
            Console.Clear();
            Console.WriteLine("|----------------------------------------|");
            Console.WriteLine("         SEARCH FOR AN ACCOUNT         ");
            Console.WriteLine("|----------------------------------------|");
            Console.WriteLine("          ENTER YOUR DETAILS             ");
            Console.WriteLine("|----------------------------------------|");

            //This checks if the input is int with less than 11 characters
            do
            {
                Console.Write("Account number: ");
                userInput = Console.ReadLine();
                // to capture postiion of cursos
                int CursorPodLeft = Console.CursorLeft;
                int CursorPosTop = Console.CursorTop;
                Console.SetCursorPosition(CursorPodLeft, CursorPosTop);

            if ((!int.TryParse(userInput, out accountId)) || (userInput.Length >= MaxLength))
            {
                Console.WriteLine("Invalid ID format!");
                Console.WriteLine("Remember it must contain up to 10 digits only");
            } else
            {
                Customer foundAccount = AccountSearch.SearchAccount(accountId);

                if (foundAccount == null)
                {
                    Console.WriteLine("Account not found!");
                    Console.Write("Do you want to try again? (y/n)");
                    string input = Console.ReadLine();
                    switch (input)
                    {
                        case "y":
                            SearchAccount();
                            break;

                        case "n":
                            MainMenu menu = new MainMenu();
                            menu.ShowOptions();
                            break;

                        default:
                            Console.WriteLine("That is not a valid option.");
                            Console.WriteLine("We will take you back to Main Menu.");
                            Thread.Sleep(5000);
                            MainMenu menu2 = new MainMenu();
                            menu2.ShowOptions();
                            break;
                    }
                }
                else
                {
            //Display user details
                    Console.WriteLine("|----------------------------------------|");
                    Console.WriteLine("            ACCOUNT DETAILS               ");
                    Console.WriteLine("|----------------------------------------|");
                    Console.WriteLine(" The details of your account are:");
                    Console.WriteLine();
                    Console.WriteLine(" 1.First Name: " + foundAccount.FirstName);
                    Console.WriteLine(" 2.Last Name: " + foundAccount.LastName);
                    Console.WriteLine(" 3.Address: " + foundAccount.Address);
                    Console.WriteLine(" 4.Phone: " + foundAccount.Phone);
                    Console.WriteLine(" 5.Email: " + foundAccount.Email);
                    Console.WriteLine(" 6.Balance: $" + foundAccount.Balance);
                    Console.WriteLine("|----------------------------------------|");
                    }
            }

            } while ((!int.TryParse(userInput, out accountId))||(userInput.Length >= MaxLength));

        }

        //Method to deposit.
        public void SearchAccountForDeposit()
            {
                Console.Clear();
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("         SEARCH FOR AN ACCOUNT         ");
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("          ENTER YOUR DETAILS             ");
                Console.WriteLine("|----------------------------------------|");

                //This checks if the input is int with less than 11 characters
                do
                {

                    Console.Write("Account number: ");
                    userInput = Console.ReadLine();
                    // to capture postiion of cursos
                    int CursorPodLeft = Console.CursorLeft;
                    int CursorPosTop = Console.CursorTop;
                    Console.SetCursorPosition(CursorPodLeft, CursorPosTop);

                    if ((!int.TryParse(userInput, out accountId)) || (userInput.Length >= MaxLength))
                    {
                        Console.WriteLine("|----------------------------------------|");
                        Console.WriteLine("Invalid ID format.");
                        Console.WriteLine("Please try agian!");
                    }
                    else
                    {
                        Customer foundAccount = AccountSearch.SearchAccount(accountId);

                        if (foundAccount == null)
                        {
                            Console.WriteLine("|----------------------------------------|");
                            Console.WriteLine("Account not found!");
                            Console.Write("Do you want to try again? (y/n)");
                            string input = Console.ReadLine();
                            switch (input)
                            {
                                case "y":
                                    SearchAccountForDeposit();
                                    break;

                                case "n":
                                    MainMenu menu = new MainMenu();
                                    menu.ShowOptions();
                                    break;

                                default:
                                    Console.WriteLine("That is not a valid option");
                                    Console.WriteLine("We will take you back to Main Menu.");
                                    Thread.Sleep(5000);
                                    MainMenu menu2 = new MainMenu();
                                    menu2.ShowOptions();
                                    break;
                            }

                        }
                        else
                        {
                            var currentBalance = foundAccount.Deposit();
                            Console.WriteLine("Current balance after deposit is: " + currentBalance);
                        }
                    }

                } while ((!int.TryParse(userInput, out accountId)) || (userInput.Length >= MaxLength));

            }

        //Method to withdraw.
        public void SearchAccountForWithdraw()
        {
 
                    Console.Clear();
                    Console.WriteLine("|----------------------------------------|");
                    Console.WriteLine("         SEARCH FOR AN ACCOUNT         ");
                    Console.WriteLine("|----------------------------------------|");
                    Console.WriteLine("          ENTER YOUR DETAILS             ");
                    Console.WriteLine("|----------------------------------------|");

                    //This checks if the input is int with less than 11 characters
                    do
                    {

                        Console.Write("Account number: ");
                        userInput = Console.ReadLine();
                        // to capture postiion of cursos
                        int CursorPodLeft = Console.CursorLeft;
                        int CursorPosTop = Console.CursorTop;
                        Console.SetCursorPosition(CursorPodLeft, CursorPosTop);

                        if ((!int.TryParse(userInput, out accountId)) || (userInput.Length >= MaxLength))
                        {
                            Console.WriteLine("Invalid ID format!");
                            Console.WriteLine("Remember it must contain up to 10 digits only");
                        }
                        else
                        {
                            Customer foundAccount = SearchAccount(accountId);

                            if (foundAccount == null)
                            {
                                Console.WriteLine("Account not found!");
                                Console.Write("Do you want to try again? (y/n)");
                                string input = Console.ReadLine();
                                switch (input)
                                {
                                    case "y":
                                    SearchAccountForWithdraw();
                                        break;

                                    case "n":
                                        MainMenu menu = new MainMenu();
                                        menu.ShowOptions();
                                        break;

                                    default:
                                        Console.WriteLine("That is not a valid option");
                                        Console.WriteLine("We will take you back to Main Menu.");
                                        Thread.Sleep(5000);
                                        MainMenu menu2 = new MainMenu();
                                        menu2.ShowOptions();
                                        break;
                                }

                            }
                            else
                            {
                                var currentBalance = foundAccount.Withdraw();
                                Console.WriteLine("Current balance after withdraw is: " + currentBalance);
              
                }
                        }

                    } while ((!int.TryParse(userInput, out accountId)) || (userInput.Length >= MaxLength));
                }

        //Method to display statement.
        public void SearchStatement()
            {
                Console.Clear();
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("         SEARCH FOR AN ACCOUNT         ");
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("          ENTER YOUR DETAILS             ");
                Console.WriteLine("|----------------------------------------|");

                //This checks if the input is int with less than 11 characters
                do
                {
                    Console.Write("Account number: ");
                    userInput = Console.ReadLine();
                    // to capture postiion of cursos
                    int CursorPodLeft = Console.CursorLeft;
                    int CursorPosTop = Console.CursorTop;
                    Console.SetCursorPosition(CursorPodLeft, CursorPosTop);

                    if ((!int.TryParse(userInput, out accountId)) || (userInput.Length >= MaxLength))
                    {
                        Console.WriteLine("Invalid ID format!");
                        Console.WriteLine("Remember it must contain up to 10 digits only");
                    }
                    else
                    {
                        Customer foundAccount = SearchAccount(accountId);

                        if (foundAccount == null)
                        {
                            Console.WriteLine("Account not found!");
                            Console.Write("Do you want to try again? (y/n)");
                            string input = Console.ReadLine();
                            switch (input)
                            {
                                case "y":
                                    SearchStatement();
                                    break;

                                case "n":
                                    MainMenu menu = new MainMenu();
                                    menu.ShowOptions();
                                    break;

                                default:
                                    Console.WriteLine("That is not a valid option");
                                    Console.WriteLine("We will take you back to Main Menu.");
                                    Thread.Sleep(5000);
                                    MainMenu menu2 = new MainMenu();
                                    menu2.ShowOptions();
                                    break;
                            }
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("|----------------------------------------------|");
                            Console.WriteLine("            ACCOUNT DETAILS               ");
                            Console.WriteLine("|----------------------------------------------|");
                            Console.WriteLine(" The details of your account are:");
                            Console.WriteLine();
                            Console.WriteLine(" 1.First Name: " + foundAccount.FirstName);
                            Console.WriteLine(" 2.Last Name: " + foundAccount.LastName);
                            Console.WriteLine(" 3.Address: " + foundAccount.Address);
                            Console.WriteLine(" 4.Phone: " + foundAccount.Phone);
                            Console.WriteLine(" 5.Email: " + foundAccount.Email);
                            Console.WriteLine(" 6.Balance: $" + foundAccount.Balance);
                            foundAccount.DisplayResult();
                            Console.WriteLine("|----------------------------------------------|");
                            Console.Write("Email statements? (y/n)");
                            string input = Console.ReadLine();
                            int CursorPosLeft = Console.CursorLeft;
                            int CursorPosiTop = Console.CursorTop;
                            Console.SetCursorPosition(CursorPosLeft, CursorPosiTop);
                            switch (input)
                            {
                                case "y":
                                    SendTransactionEmail(); 
                                    break;

                                case "n":
                                    MainMenu menu = new MainMenu();
                                    menu.ShowOptions();
                                    break;
                                
                                default:
                                    Console.WriteLine("That is not a valid option");
                                    Console.WriteLine("We will take you back to Main Menu.");
                                    Thread.Sleep(5000);
                                    MainMenu menu2 = new MainMenu();
                                    menu2.ShowOptions();
                                    break;
                            }

                        }
                    }

                } while ((!int.TryParse(userInput, out accountId)) || (userInput.Length >= MaxLength));
            }

        //Method to delete account.
        public void SearchForDelete()
            {
                Console.Clear();
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("         SEARCH FOR AN ACCOUNT         ");
                Console.WriteLine("|----------------------------------------|");
                Console.WriteLine("          ENTER YOUR DETAILS             ");
                Console.WriteLine("|----------------------------------------|");

                //This checks if the input is int with less than 11 characters
                do
                {

                    Console.Write("Account number: ");
                    userInput = Console.ReadLine();
                    // to capture postiion of cursos
                    int CursorPodLeft = Console.CursorLeft;
                    int CursorPosTop = Console.CursorTop;
                    Console.SetCursorPosition(CursorPodLeft, CursorPosTop);

                    if ((!int.TryParse(userInput, out accountId)) || (userInput.Length >= MaxLength))
                    {
                        Console.WriteLine("Invalid ID format!");
                        Console.WriteLine("Remember it must contain up to 10 digits only");
                    }
                    else
                    {
                        Customer foundAccount = SearchAccount(accountId);

                        if (foundAccount == null)
                        {
                            Console.WriteLine("Account not found!");
                            Console.Write("Do you want to try again? (y/n)");
                            string input = Console.ReadLine();
                            switch (input)
                            {
                                case "y":
                                    SearchForDelete();
                                    break;

                                case "n":
                                    MainMenu menu = new MainMenu();
                                    menu.ShowOptions();
                                    break;

                                default:
                                    Console.WriteLine("That is not a valid option.");
                                    Console.WriteLine("We will take you back to Main Menu.");
                                    Thread.Sleep(5000);
                                    MainMenu menu2 = new MainMenu();
                                    menu2.ShowOptions();
                                    break;
                            }
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("|----------------------------------------------|");
                            Console.WriteLine("            ACCOUNT DETAILS               ");
                            Console.WriteLine("|----------------------------------------------|");
                            Console.WriteLine(" The details of your account are:");
                            Console.WriteLine();
                            Console.WriteLine(" 1.First Name: " + foundAccount.FirstName);
                            Console.WriteLine(" 2.Last Name: " + foundAccount.LastName);
                            Console.WriteLine(" 3.Address: " + foundAccount.Address);
                            Console.WriteLine(" 4.Phone: " + foundAccount.Phone);
                            Console.WriteLine(" 5.Email: " + foundAccount.Email);
                            Console.WriteLine(" 6.Balance: $" + foundAccount.Balance);
                            Console.WriteLine("|----------------------------------------------|");
                            Console.Write("Do you want to delete the account? (y/n)");
                            string input = Console.ReadLine();
                            int CursorPosLeft = Console.CursorLeft;
                            int CursorPosiTop = Console.CursorTop;
                            Console.SetCursorPosition(CursorPosLeft, CursorPosiTop);
                            switch (input)
                            {
                                case "y":
                                    foundAccount.DeleteAccount();
                                    break;

                                case "n":
                                    MainMenu menu = new MainMenu();
                                    menu.ShowOptions();
                                    break;

                                default:
                                    Console.WriteLine("That is not a valid option");
                                    Console.WriteLine("We will take you back to Main Menu.");
                                    Thread.Sleep(5000);
                                    MainMenu menu2 = new MainMenu();
                                    menu2.ShowOptions();
                                    break;
                            }

                        }
                    }

                } while ((!int.TryParse(userInput, out accountId)) || (userInput.Length >= MaxLength));
            }

        //Method to send transaction email.
        public void SendTransactionEmail()
                {
                    try
                    {
                        Customer foundAccount = SearchAccount(accountId);
                        var path = "Accounts/" + accountId + ".txt";
                        MailMessage mail = new MailMessage();
                        SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
                        mail.From = new MailAddress("hdbankingapp@gmail.com");
                        mail.To.Add(foundAccount.Email);
                        mail.Subject = "Banking App - Transaction Statements";
                        mail.Body = "Hi there! Please find attached your transaction details";

                    using (Attachment attachment = new Attachment(path))
                    {
                        mail.Attachments.Add(attachment);
                        SmtpServer.Port = 587;
                        SmtpServer.Credentials = new System.Net.NetworkCredential("hdbankingapp@gmail.com", "13416793");
                        SmtpServer.EnableSsl = true;
                        SmtpServer.Send(mail);
                    }
                        //System.Net.Mail.Attachment attachment;
                        //attachment = new System.Net.Mail.Attachment(path);
                       // mail.Attachments.Add(attachment);
                       // SmtpServer.Port = 587;
                       // SmtpServer.Credentials = new System.Net.NetworkCredential("hdbankingapp@gmail.com", "13416793");
                      //  SmtpServer.EnableSsl = true;
                      //  SmtpServer.Send(mail);
                        Console.WriteLine("Your details were sent to your email!\nYou can now proceed back to the menu/");
                        Thread.Sleep(2000);

                        // takes back to main menu option
                        MainMenu menu = new MainMenu();
                        menu.ShowOptions();
                    }
                    catch (Exception)
                    {
                    Console.Clear();
                    Console.WriteLine("|----------------------------------------|");
                    Console.WriteLine("         OOPS! WE ARE SORRY        ");
                    Console.WriteLine("|----------------------------------------|");
                    Console.WriteLine("There was an error while sending the email.");
                    Console.WriteLine("Please contact support to fix it.");
                    Console.WriteLine("You can now proceed back to the menu");
                    Thread.Sleep(5200);
                    MainMenu menu = new MainMenu();
                    menu.ShowOptions();

                    }
                }

        //Method overloading to search for customer by using the accountId.
        public static Customer SearchAccount(int accountId)
            {
                // to capture postiion of cursos
                int CursorPodLeft = Console.CursorLeft;
                int CursorPosTop = Console.CursorTop;
                Console.SetCursorPosition(CursorPodLeft, CursorPosTop);
                //to check the fields from the file and convert them in an object
                try
                {
                    string firstName = "";
                    string lastName = "";
                    string address = "";
                    string phone = "";
                    string email = "";
                    string accountNumber = "";
                    double balance = 0;
                    ArrayList transactions = new ArrayList();
                //foreach loop to read through the lines of the file with : as delimiter.
                //store values in new customer.
                    foreach (string line in File.ReadLines("Accounts/" + accountId + ".txt"))
                    {
                        string[] spilttedString = line.Split(":");
                        if (spilttedString.Length < 2) {
                            Console.WriteLine("File is corrupted, cannot split string with ':'");
                            return null;
                        }
                        var key = spilttedString[0];
                        var value = spilttedString[1];
                        switch (key)
                        {
                            case "Account Number":
                                accountNumber = value;
                                break;
                            case "Account Balance":
                                balance = Convert.ToDouble(value);
                                break;
                            case "First Name":
                                firstName = value;
                                break;
                            case "Last Name":
                                lastName = value;
                                break;
                            case "Address":
                                address = value;
                                break;
                            case "Phone":
                                phone = value;
                                break;
                            case "Email":
                                email = value;
                                break;
                            case "Transaction details":
                            var trans = value;
                            transactions.Add("Transaction details:"+value);
                            break;
                        }
                    }
                    Customer customer = new Customer(accountId, firstName, lastName, phone, address, email, balance, transactions);
                    return customer;
                }
                catch (System.IO.FileNotFoundException)
                {
                    return null;
                }
            }
    }
}
