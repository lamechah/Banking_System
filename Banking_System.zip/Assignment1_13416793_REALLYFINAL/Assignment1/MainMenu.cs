﻿using System;
using System.Threading;
namespace Assignment1
{
    public class MainMenu
    {
        //Declare data variables
        string userInput;
        int option;
        public MainMenu()
        {
        }

        // Method to show the Main Menu options and switch between them.
        public int ShowOptions()
        {
            Console.Clear();
            Console.WriteLine("|----------------------------------------|");
            Console.WriteLine("         WELCOME TO BANKING SYSTEM        ");
            Console.WriteLine("|----------------------------------------|");
            Console.WriteLine("             1.Create a new account:      ");
            Console.WriteLine("             2.Search for an account:     ");
            Console.WriteLine("             3.Deposit:                   ");
            Console.WriteLine("             4.Withdraw:                  ");
            Console.WriteLine("             5.A/C statement:             ");
            Console.WriteLine("             6.Delete Account:            ");
            Console.WriteLine("             7.Exit:                      ");
            Console.WriteLine("|----------------------------------------|");
            Console.Write("Please enter an option (1-7):");
            try
            { 
            userInput = Console.ReadLine();
            option = Convert.ToInt32(userInput);
                switch (option)
                {
                    case 1:
                        NewCustomer newcustomer = new NewCustomer();
                        newcustomer.CreateAccount();
                        return 1;
                    case 2:
                        AccountSearch account = new AccountSearch ();
                        account.SearchAccount();
                        return 2;
                    case 3:
                        AccountSearch depositAccount = new AccountSearch();
                        depositAccount.SearchAccountForDeposit();
                        return 3;
                    case 4:
                        AccountSearch withdrawAccount = new AccountSearch();
                        withdrawAccount.SearchAccountForWithdraw();
                        return 4;
                    case 5:
                        AccountSearch statements = new AccountSearch();
                        statements.SearchStatement();
                        return 5;
                    case 6:
                        AccountSearch delete = new AccountSearch();
                        delete.SearchForDelete();
                        return 6;
                    case 7:
                        Login exit = new Login();
                        exit.LoginScreen();
                        return 7;
                    default:
                        Console.WriteLine("That is an invalid option. Please try again!");
                        Thread.Sleep(2500);
                        ShowOptions();
                        return 7;
                }
            }
            //Implement try-catch blocks to handle wrong input from customer.
            catch (Exception)
            { 
            Console.WriteLine("That is an invalid option. Please try again!");
            Thread.Sleep(2500);
            ShowOptions();
            return 7;
            }
        }
    }
}
